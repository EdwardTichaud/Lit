using System;
using System.IO;
using System.Linq;
using UnityEditor;
using UnityEditor.Build.Reporting;
using UnityEditor.SceneManagement;
using UnityEngine;

public static class PersistencePlayerBuild
{
    public static void Run()
    {
        try
        {
            string project = Path.GetFullPath(".");
            if (!Application.isBatchMode || Directory.Exists(Path.Combine(project, ".git")) ||
                !project.EndsWith("MovingLegsValidationProject", StringComparison.OrdinalIgnoreCase))
                throw new InvalidOperationException("Only the isolated non-Git validation copy may build this recipe.");
            string output = Path.GetFullPath("../PersistenceContinuityValidation/Player");
            string run = Path.Combine(output, "Runs", Guid.NewGuid().ToString("N"));
            Directory.CreateDirectory(run);
            Directory.CreateDirectory("Assets/__PersistenceValidation/Scene");
            var scene = EditorSceneManager.OpenScene("Assets/Scenes/Bootstrap.unity", OpenSceneMode.Single);
            var flow = scene.GetRootGameObjects().SelectMany(root => root.GetComponentsInChildren<GameFlowService>(true)).Single();
            var saves = scene.GetRootGameObjects().SelectMany(root => root.GetComponentsInChildren<SaveSessionManager>(true)).Single();
            var flowData = new SerializedObject(flow);
            flowData.FindProperty("editorStartGameplayDirectly").boolValue = false;
            flowData.FindProperty("loadMenuAfterBootstrap").boolValue = true;
            flowData.ApplyModifiedPropertiesWithoutUndo();
            var savesData = new SerializedObject(saves);
            savesData.FindProperty("savesRootFolder").stringValue = Path.Combine(run, "Saves");
            savesData.ApplyModifiedPropertiesWithoutUndo();
            var probe = new GameObject("PersistencePlayerProbe").AddComponent<PersistencePlayerProbe>();
            probe.house = AssetDatabase.LoadAssetAtPath<ZoneManifest>("Assets/Scenes/Maison/ZoneManifest_Maison.asset");
            probe.district = AssetDatabase.LoadAssetAtPath<ZoneManifest>("Assets/Scenes/Maison/ZoneManifest_District_1.asset");
            probe.runDirectory = run;
            if (probe.house == null || probe.district == null) throw new InvalidOperationException("Real zone manifests required.");
            EditorSceneManager.SaveScene(scene, "Assets/__PersistenceValidation/Scene/Bootstrap.unity");
            string company = UnityEditor.PlayerSettings.companyName, product = UnityEditor.PlayerSettings.productName;
            var backend = UnityEditor.PlayerSettings.GetScriptingBackend(UnityEditor.Build.NamedBuildTarget.Standalone);
            try
            {
                UnityEditor.PlayerSettings.companyName = "LitIsolatedValidation";
                UnityEditor.PlayerSettings.productName = "PersistencePlayerProbe";
                UnityEditor.PlayerSettings.SetScriptingBackend(UnityEditor.Build.NamedBuildTarget.Standalone, ScriptingImplementation.Mono2x);
                var scenes = new[] { "Assets/__PersistenceValidation/Scene/Bootstrap.unity" }.Concat(
                    EditorBuildSettings.scenes.Where(entry => entry.enabled && entry.path != "Assets/Scenes/Bootstrap.unity").Select(entry => entry.path)).ToArray();
                var build = BuildPipeline.BuildPlayer(new BuildPlayerOptions {
                    scenes = scenes, target = BuildTarget.StandaloneWindows64,
                    locationPathName = Path.Combine(output, "PersistenceProbe.exe"), options = BuildOptions.Development
                });
                File.WriteAllText(Path.Combine(output, "build-summary.json"), JsonUtility.ToJson(new Summary {
                    passed = build.summary.result == BuildResult.Succeeded, runDirectory = run,
                    result = build.summary.result.ToString(), errors = build.summary.totalErrors,
                    seconds = build.summary.totalTime.TotalSeconds, bytes = build.summary.totalSize
                }, true));
                if (build.summary.result != BuildResult.Succeeded) throw new InvalidOperationException("Player build failed: " + build.summary.result);
                File.WriteAllText(Path.Combine(output, "latest-run.txt"), run);
            }
            finally
            {
                UnityEditor.PlayerSettings.companyName = company; UnityEditor.PlayerSettings.productName = product;
                UnityEditor.PlayerSettings.SetScriptingBackend(UnityEditor.Build.NamedBuildTarget.Standalone, backend);
            }
            EditorApplication.Exit(0);
        }
        catch (Exception error) { Debug.LogException(error); EditorApplication.Exit(1); }
    }
    [Serializable] private sealed class Summary
    {
        public bool passed;
        public string result, runDirectory;
        public int errors;
        public ulong bytes;
        public double seconds;
    }
}
