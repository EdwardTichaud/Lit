using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using Unity.Netcode;
using UnityEngine;
using UnityEngine.SceneManagement;

// Validation-copy only. Direct loopback transport exercises real NGO objects,
// ownership and snapshots; it does not qualify Relay/invitation UX.
[DefaultExecutionOrder(-19000)]
public sealed class PersistenceNetworkProbe : MonoBehaviour
{
    public ZoneManifest house, district;
    public string runDirectory, sharedDirectory, role;
    [Serializable] private sealed class Report
    {
        public bool passed, fullProductionReadiness;
        public string reason, scope = "Two independent Unity processes, production Bootstrap/NGO direct loopback, Maison late join, local session readiness, one snapshot application, real inventory RPC and host save. No zone portal/rejoin/Relay/manual-input proof.";
        public List<string> checks = new List<string>(), errors = new List<string>();
    }
    [Serializable] private sealed class Offer { public string dropId, itemId; public int quantity; }
    private readonly Report report = new Report();
    private int stage, ownInventoryBefore, hostInventoryAfterDrop;
    private double stageStarted, heartbeat, synchronizedAt;
    private bool finished, synchronized, clientMenuReadySignaled;
    private string dropId, itemId;
    private HashSet<string> identitiesBeforeDrop;
    private const ushort Port = 17739;
    private const BindingFlags Private = BindingFlags.Instance | BindingFlags.NonPublic;
    private NetworkManager manager;
    private SquadCharacterController firstActor;
    private int clientSnapshotApplications;
    private WorldStateManager observedWorld;
    private void SnapshotApplied(WorldSnapshot snapshot) => clientSnapshotApplications++;

    private void Awake()
    {
        if (!Debug.isDebugBuild || !Environment.GetCommandLineArgs().Contains("-persistence-validation") ||
            role != "host" && role != "client") { enabled = false; return; }
        DontDestroyOnLoad(gameObject);
        Application.runInBackground = true;
        Directory.CreateDirectory(runDirectory);
        Directory.CreateDirectory(sharedDirectory);
        Application.logMessageReceived += Observe;
        Advance(0);
    }
    private void OnDestroy()
    {
        if (observedWorld != null) observedWorld.SnapshotApplied -= SnapshotApplied;
        Application.logMessageReceived -= Observe;
        if (manager != null && manager.SceneManager != null) manager.SceneManager.OnSceneEvent -= SceneEvent;
    }
    private void SceneEvent(SceneEvent sceneEvent)
    {
        if (sceneEvent.SceneEventType == SceneEventType.SynchronizeComplete)
        { synchronized = true; synchronizedAt = Time.realtimeSinceStartupAsDouble; }
    }
    private void Observe(string message, string stack, LogType type)
    {
        if (type == LogType.Error || type == LogType.Exception || type == LogType.Assert)
            report.errors.Add(message + "\n" + stack);
    }
    private void Update()
    {
        if (finished) return;
        try
        {
            if (Time.realtimeSinceStartupAsDouble > heartbeat)
            {
                heartbeat = Time.realtimeSinceStartupAsDouble + 15;
                Write("Running stage=" + stage + " role=" + role);
                Debug.Log("[PersistenceNetwork] " + report.reason + " connected=" + manager?.IsConnectedClient +
                    " session=" + GameFlowService.Instance?.HasGameplaySession + " sync=" + JoinSyncSystem.Instance?.IsLocalWorldReady);
            }
            // Waiting for the other editor's startup is not a connection attempt.
            // The editor wrapper still bounds the whole recipe to 30 minutes.
            if (role == "client" && stage == 0 && clientMenuReadySignaled && !Exists("host-ready"))
                stageStarted = Time.realtimeSinceStartupAsDouble;
            if (Time.realtimeSinceStartupAsDouble - stageStarted > 240)
                throw new TimeoutException("stage=" + stage + " role=" + role + " syncEvent=" + synchronized +
                    " localRoot=" + LocalPlayerContext.LocalCharacterRoot + " session=" + GameFlowService.Instance?.HasGameplaySession +
                    " nav=" + NavMeshWorldService.Instance?.State + " mode=" + InputModeCoordinator.CurrentMode);
            Tick();
        }
        catch (Exception error) { Finish(false, error.ToString()); }
    }
    private void Tick()
    {
        var flow = GameFlowService.Instance;
        if (flow == null) return;
        if (stage == 0)
        {
            if (flow.IsTransitioning || !SceneManager.GetSceneByName("MainMenu").isLoaded || Time.frameCount < 10) return;
            if (role == "client" && !clientMenuReadySignaled)
            {
                Signal("client-menu-ready");
                clientMenuReadySignaled = true;
            }
            if (role == "client" && !Exists("host-ready")) return;
            Check(!flow.HasGameplaySession, "Bootstrap menu has no pre-created gameplay session");
            GameplayRuntimeReset.PrepareForGameplayStart("persistence_network_fixture_prepare");
            var saves = SaveSessionManager.Instance;
            Check(Path.GetFullPath(saves.GetSavesRoot()) == Path.Combine(runDirectory, "Saves"), "Profile saves isolated");
            saves.SetCurrentSessionType(SaveSessionType.Multiplayer);
            manager = NetworkManager.Singleton;
            var launcher = FindAnyObjectByType<NetcodeLauncher>();
            Check(manager != null && launcher != null, "Authored network bootstrap and launcher available");
            if (role == "host")
            {
                var session = saves.CreateSession("Network continuity fixture", SaveSessionType.Multiplayer);
                var slot = saves.CreateSave(session.sessionId, "Host authority");
                saves.SetActiveSave(session.sessionId, slot.saveId);
                Check(launcher.StartHostWithConnection("127.0.0.1", Port, "127.0.0.1"), "Real loopback host listening");
                Check(GameFlowService.StartOrLoadGame(house.PrimarySceneName), "Host starts actual Maison manifest");
            }
            else
            {
                observedWorld = WorldStateManager.Instance;
                Check(observedWorld != null, "Client world snapshot service available before connection");
                observedWorld.SnapshotApplied += SnapshotApplied;
                saves.ClearActiveSave();
                Check(launcher.StartClientWithConnection("127.0.0.1", Port), "Real independent client connects late");
                manager.SceneManager.OnSceneEvent += SceneEvent;
            }
            Advance(1); return;
        }
        var actor = LocalPlayerContext.LocalCharacterRoot != null ? LocalPlayerContext.LocalCharacterRoot.GetComponent<SquadCharacterController>() : null;
        if (role == "client") { TickClient(flow, actor); return; }
        if (stage == 1)
        {
            if (flow.IsTransitioning || actor == null || !Ready(house)) return;
            Check(manager.IsServer && manager.IsHost, "Only host is the authoritative server");
            firstActor = actor;
            var item = actor.Items.Where(value => value != null).Distinct().FirstOrDefault(value =>
                actor.Items.Count(other => other == value) >= 3 && !value.isBuilding && value.CanInstantDropFromInventory(actor, false, out _) && value.ResolveWorldPrefab() != null);
            Check(item != null, "Authored host inventory supports real three-unit drop");
            itemId = ItemIdUtils.GetItemId(item);
            identitiesBeforeDrop = new HashSet<string>(FindObjectsByType<PersistentNetworkObject>(FindObjectsInactive.Include).Select(value => value.PersistentId));
            hostInventoryAfterDrop = Count(actor, itemId) - 3;
            Check(actor.GetComponent<NetworkInventory>().RequestDropItem(item, 3, actor.transform.position + actor.transform.forward, Quaternion.identity, false, true), "Host production drop requested");
            Advance(2); return;
        }
        if (stage == 2)
        {
            var drop = FindObjectsByType<PersistentNetworkObject>(FindObjectsInactive.Include).FirstOrDefault(value =>
                !identitiesBeforeDrop.Contains(value.PersistentId) && value.ObjectKind == PersistentObjectKind.RuntimeSpawned && value.GetComponent<InteractableItem>() is InteractableItem container && Quantity(container, itemId) == 3);
            if (drop == null) return;
            dropId = drop.PersistentId;
            foreach (var entry in FindObjectsByType<NetworkObject>(FindObjectsInactive.Include))
            {
                if (!entry.IsSpawned) continue;
                Debug.Log("[PersistenceNetwork] ObjectHash name='" + entry.name + "' scene='" + entry.gameObject.scene.name +
                    "' hash=" + typeof(NetworkObject).GetField("GlobalObjectIdHash", Private)?.GetValue(entry) +
                    " prefabHash=" + typeof(NetworkObject).GetField("PrefabGlobalObjectIdHash", Private)?.GetValue(entry) +
                    " inScene=" + entry.IsSceneObject + " id='" + entry.GetComponent<PersistentNetworkObject>()?.PersistentId + "'");
            }
            Check(drop.GetComponent<NetworkObject>()?.IsSpawned == true, "Drop has actual spawned NGO identity before late join");
            File.WriteAllText(Path.Combine(sharedDirectory, "offer.json"), JsonUtility.ToJson(new Offer {dropId=dropId,itemId=itemId,quantity=3}));
            Signal("host-ready"); Advance(3); return;
        }
        if (stage == 3)
        {
            if (!Exists("client-world-ready")) return;
            Check(manager.ConnectedClientsIds.Count == 2, "Host sees one real remote client");
            ulong remote = manager.ConnectedClientsIds.Single(id => id != manager.LocalClientId);
            Check(JoinSyncSystem.Instance.IsClientReady(remote), "Host received client snapshot acknowledgement");
            var remoteActor = NetcodePlayerUtils.GetPlayerTransform(remote)?.GetComponent<SquadCharacterController>();
            Check(remoteActor != null && remoteActor != actor, "Separate actor assigned to remote player");
            Check(remoteActor.GetComponent<NetworkObject>().OwnerClientId == remote, "Remote actor retains correct NGO owner");
            Check(remoteActor.TrySetUccExternalPositionAndRotation(actor.transform.position + actor.transform.right * .6f, actor.transform.rotation, true), "Server UCC approach fixture positions remote actor near real drop");
            Signal("take-requested"); Advance(4); return;
        }
        if (stage == 4)
        {
            if (!Exists("client-take-confirmed") || Quantity(FindDrop(), itemId) != 2) return;
            Check(Count(actor, itemId) == hostInventoryAfterDrop, "Remote pickup does not credit host inventory");
            Check(actor == firstActor, "Host actor unchanged by late join and remote pickup");
            Check(WorldStateManager.Instance.CaptureSnapshot("network continuity fixture") != null && WorldStateManager.Instance.LastCaptureSucceeded,
                "Authoritative world snapshot captures both players and partially consumed drop");
            CharacterStateStore.Instance.Save(); Advance(5); return;
        }
        if (stage == 5)
        {
            if (CharacterStateStore.Instance.IsSaving) return;
            Check(CharacterStateStore.Instance.LastSaveSucceeded, "Host commits actual multiplayer save");
            Signal("host-saved"); Advance(6); return;
        }
        if (stage == 6 && Exists("client-complete"))
        {
            Check(report.errors.Count == 0, "No runtime errors during first actual network continuity gate");
            Finish(true, "Late join, authoritative partial pickup and host disk commit validated. Zone transfer/rejoin/disk reload remain separate gates.");
        }
    }
    private void TickClient(GameFlowService flow, SquadCharacterController actor)
    {
        if (stage == 1)
        {
            if (!manager.IsConnectedClient || !synchronized || JoinSyncSystem.Instance == null || !JoinSyncSystem.Instance.IsLocalWorldReady || actor == null) return;
            if (Time.realtimeSinceStartupAsDouble - synchronizedAt < 2) return;
            Check(flow.HasGameplaySession, "Client owns a complete local gameplay session after native scene sync");
            Check(clientSnapshotApplications == 1, "Client applies world snapshot once while preparing local services");
            Check(!manager.IsServer && !SaveSessionManager.Instance.HasActiveSave, "Client neither owns server authority nor writes host slot");
            Check(actor.GetComponent<NetworkObject>() is NetworkObject networkActor && networkActor.IsSpawned && networkActor.OwnerClientId == manager.LocalClientId,
                "Client controls only its real owned network actor");
            Check(NavMeshWorldService.Instance != null && NavMeshWorldService.Instance.IsReady, "Client gameplay navigation service ready");
            var offer = JsonUtility.FromJson<Offer>(File.ReadAllText(Path.Combine(sharedDirectory, "offer.json")));
            dropId = offer.dropId; itemId = offer.itemId;
            Check(Quantity(FindDrop(), itemId) == offer.quantity, "Late join reconstructed existing drop with stable ID and quantity");
            ownInventoryBefore = Count(actor, itemId);
            Signal("client-world-ready"); Advance(2); return;
        }
        if (stage == 2)
        {
            if (!Exists("take-requested") || actor == null) return;
            var drop = FindDrop();
            if (drop == null || Vector3.Distance(actor.transform.position, drop.transform.position) > 2) return;
            Check(drop.CanBeDetectedBy(actor) && !drop.IsLockedForInteraction(), "Remote pickup satisfies production influence/lock gates");
            drop.SetDetectedCharacter(actor.gameObject);
            var entry = drop.storedItems.Single(value => value.item != null && ItemIdUtils.GetItemId(value.item) == itemId);
            Check((bool)typeof(InteractableItem).GetMethod("PerformTake", Private).Invoke(drop, new object[] {entry, 1}), "Remote take uses existing production ServerRpc");
            Advance(3); return;
        }
        if (stage == 3)
        {
            if (actor == null || Count(actor, itemId) != ownInventoryBefore + 1 || Quantity(FindDrop(), itemId) != 2) return;
            Check(true, "Client inventory and shared world quantity converge after server-authoritative pickup");
            Signal("client-take-confirmed"); Advance(4); return;
        }
        if (stage == 4 && Exists("host-saved"))
        {
            Check(!Directory.Exists(Path.Combine(runDirectory, "Saves")) || !Directory.EnumerateFiles(Path.Combine(runDirectory, "Saves"), "CharacterState.json", SearchOption.AllDirectories).Any(),
                "Remote client wrote no character save to disk");
            Check(report.errors.Count == 0, "No runtime errors during client continuity gate");
            Signal("client-complete"); Finish(true, "Actual client late join and pickup validated; transition/rejoin/reload remain unqualified.");
        }
    }
    private bool Ready(ZoneManifest zone) => !GameFlowService.Instance.IsTransitioning &&
        zone.LoadingSceneNames.Concat(zone.PostLoadingSceneNames).Concat(new[]{zone.PrimarySceneName}).All(name=>SceneManager.GetSceneByName(name).isLoaded) && NavMeshWorldService.Instance?.IsReady == true;
    private InteractableItem FindDrop() => FindObjectsByType<PersistentNetworkObject>(FindObjectsInactive.Include).SingleOrDefault(value=>value.PersistentId==dropId)?.GetComponent<InteractableItem>();
    private static int Count(SquadCharacterController actor, string id) => actor.Items.Count(item=>item!=null && ItemIdUtils.GetItemId(item)==id);
    private static int Quantity(InteractableItem container, string id) => container?.storedItems?.Where(entry=>entry?.item!=null && ItemIdUtils.GetItemId(entry.item)==id).Sum(entry=>entry.quantity) ?? -1;
    private bool Exists(string name) => File.Exists(Path.Combine(sharedDirectory,name));
    private void Signal(string name) => File.WriteAllText(Path.Combine(sharedDirectory,name), role);
    private void Check(bool condition,string message) { if(!condition) throw new InvalidOperationException(message); report.checks.Add(message); Debug.Log("[PersistenceNetwork] PASS "+message); }
    private void Advance(int next) { stage=next; stageStarted=Time.realtimeSinceStartupAsDouble; Write("Running stage="+stage+" role="+role); }
    private void Write(string reason) { report.reason=reason; File.WriteAllText(Path.Combine(runDirectory,"result.json"),JsonUtility.ToJson(report,true)); }
    private void Finish(bool passed,string reason) { finished=true;report.passed=passed;Write(reason); Debug.Log("[PersistencePlayer] "+(passed?"COMPLETE ":"FAILED ")+role+" "+reason); Application.Quit(passed?0:1); }
}
